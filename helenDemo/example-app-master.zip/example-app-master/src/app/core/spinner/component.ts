import { Component } from '@angular/core';

@Component({
  selector: 'zoo-spinner',
  templateUrl: './component.html',
  styleUrls: [ './component.css' ],
})
export class SpinnerComponent {}
